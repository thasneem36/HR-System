import React from "react";

function LeaveSettings(){
    return(
        <>
            <div className="container">
                <h1>LeaveSettings</h1>
            </div>
        </>
    )
}

export default LeaveSettings;