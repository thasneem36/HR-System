import React from "react";

function Profile(){
    return(
        <>
            <div className="container">
                <h1>Profiel</h1>
            </div>
        </>
    )
}

export default Profile;