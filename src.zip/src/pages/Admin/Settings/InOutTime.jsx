import React from "react";

function InOutTime(){
    return(
        <>
            <div className="container">
                <h1>InOutTime</h1>
            </div>
        </>
    )
}

export default InOutTime;