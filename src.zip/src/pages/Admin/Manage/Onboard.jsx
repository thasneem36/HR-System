import React from "react";

function Onboard(){
    return(
        <>
        <div className="container">
            <h1>Onboard</h1>
        </div>
        </>
    )
}

export default Onboard;