import React from "react";

function People(){
    return (
        <>
        <div className="container">
            <h1>People</h1>
        </div>
        </>
    )
}

export default People;