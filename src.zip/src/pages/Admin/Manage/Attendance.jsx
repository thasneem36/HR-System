import React from "react";

function Attendance(){
    return(
        <>
        <div className="container">
            <h1>Attendance</h1>
        </div>
        </>
    )
}

export default Attendance;